#include <iostream>

struct Table_Data_Line
{
    unsigned int id;
    std::string name;
    std::string adress;
    std::string type;
    std::string services[8];
};
