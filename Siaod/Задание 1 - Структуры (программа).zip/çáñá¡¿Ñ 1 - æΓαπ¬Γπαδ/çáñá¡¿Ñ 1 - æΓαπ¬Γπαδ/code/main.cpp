#include "app.cpp"

int main()
{
    return App();
}
